﻿using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PAC_Man_Game_WPF_MOO_ICT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer gameTimer = new DispatcherTimer(); // create a new instance of the dispatcher timer called game timer

        bool goLeft, goRight, goDown, goUp; // 4 boolean created to move player in 4 direction
        bool noLeft, noRight, noDown, noUp; // 4 more boolean created to stop player moving in that direction

        bool twoPlayerMode = false; // true when co-op was chosen on the start menu

        // player 2's movement state (WASD), same idea as player 1's booleans above
        bool goLeft2, goRight2, goDown2, goUp2;
        bool noLeft2, noRight2, noDown2, noUp2;

        int speed = 8; // player speed

        Rect pacmanHitBox; // player hit box, this will be used to check for collision between player to walls, ghost and coints
        Rect pacman2HitBox; // player 2's hit box (co-op only)

        int ghostSpeed = 10; // ghost image speed
        int initialGhostSpeed = 10; // magnitude ghosts reset to after a death/restart - set per difficulty
        int ghostMoveStep = 160; // ghost step limits
        int currentGhostStep; // current movement limit for the ghosts
        int score = 0; // score keeping integer

        bool canEatGhost = false; // becomes true after eating a fruit; lets pacman kill the NEXT ghost he touches. Does not stack: eating a 2nd fruit while this is already true still only allows 1 kill.
        int glowFlashCounter = 0; // used to make the power-up glow around pacman flash on/off

        int startingLives = 3; // the player's own life plus extra lives - set per difficulty (Hard gives only 2 total)
        int lives; // how many lives are left right now

        enum Difficulty { Easy, Medium, Hard }
        Difficulty difficulty = Difficulty.Medium; // chosen on the difficulty menu before the player-count menu

        // one MediaPlayer per sound effect - kept alive for the whole window so playback
        // isn't cut off by garbage collection, and reused so replaying is instant
        readonly MediaPlayer fruitSound = new MediaPlayer();
        readonly MediaPlayer deathSound = new MediaPlayer();
        readonly MediaPlayer winSound = new MediaPlayer();

        int totalCoins; // total number of coins on the map, counted once at startup
        int coinsCollected = 0; // how many coins have been eaten so far (used for the win condition, kept separate from "score" since fruit also adds to score)

        // starting positions of pacman and the ghosts, captured once at startup so we can
        // put everything back where it belongs when the player restarts the game
        double pacmanStartLeft, pacmanStartTop;
        double pacman2StartLeft, pacman2StartTop;
        double redGuyStartLeft, redGuyStartTop;
        double orangeGuyStartLeft, orangeGuyStartTop;
        double pinkGuyStartLeft, pinkGuyStartTop;
        double blueGuyStartLeft, blueGuyStartTop;



        public MainWindow()
        {
            InitializeComponent();

            GameSetUp(); // run the game set up function
        }

        private void CanvasKeyDown(object sender, KeyEventArgs e)
        {
            // this is the key down event

            if (e.Key == Key.Left && noLeft == false)
            {
                // if the left key is down and the boolean noLeft is set to false
                goRight = goUp = goDown = false; // set rest of the direction booleans to false
                noRight = noUp = noDown = false; // set rest of the restriction boolean to false

                goLeft = true; // set go left true

                pacman.RenderTransform = new RotateTransform(-180, pacman.Width / 2, pacman.Height / 2); // rotate the pac man image to face left
            }

            if (e.Key == Key.Right && noRight == false)
            {
                // if the right key pressed and no right boolean is false
                noLeft = noUp = noDown = false; // set rest of the direction boolean to false
                goLeft = goUp = goDown = false; // set rest of the restriction boolean to false

                goRight = true; // set go right to true

                pacman.RenderTransform = new RotateTransform(0, pacman.Width / 2, pacman.Height / 2); // rotate the pac man image to face right

            }

            if (e.Key == Key.Up && noUp == false)
            {
                // if the up key is pressed and no up is set to false
                noRight = noDown = noLeft = false; // set rest of the direction boolean to false
                goRight = goDown = goLeft = false; // set rest of the restriction boolean to false

                goUp = true; // set go up to true

                pacman.RenderTransform = new RotateTransform(-90, pacman.Width / 2, pacman.Height / 2); // rotate the pac man character to face up
            }

            if (e.Key == Key.Down && noDown == false)
            {
                // if the down key is press and the no down boolean is false
                noUp = noLeft = noRight = false; // set rest of the direction boolean to false
                goUp = goLeft = goRight = false; // set rest of the restriction boolean to false

                goDown = true; // set go down to true

                pacman.RenderTransform = new RotateTransform(90, pacman.Width / 2, pacman.Height / 2); // rotate the pac man character to face down
            }

            // player 2 (co-op only) uses WASD instead of the arrow keys
            if (twoPlayerMode)
            {
                if (e.Key == Key.A && noLeft2 == false)
                {
                    goRight2 = goUp2 = goDown2 = false;
                    noRight2 = noUp2 = noDown2 = false;
                    goLeft2 = true;
                    pacman2.RenderTransform = new RotateTransform(-180, pacman2.Width / 2, pacman2.Height / 2);
                }

                if (e.Key == Key.D && noRight2 == false)
                {
                    noLeft2 = noUp2 = noDown2 = false;
                    goLeft2 = goUp2 = goDown2 = false;
                    goRight2 = true;
                    pacman2.RenderTransform = new RotateTransform(0, pacman2.Width / 2, pacman2.Height / 2);
                }

                if (e.Key == Key.W && noUp2 == false)
                {
                    noRight2 = noDown2 = noLeft2 = false;
                    goRight2 = goDown2 = goLeft2 = false;
                    goUp2 = true;
                    pacman2.RenderTransform = new RotateTransform(-90, pacman2.Width / 2, pacman2.Height / 2);
                }

                if (e.Key == Key.S && noDown2 == false)
                {
                    noUp2 = noLeft2 = noRight2 = false;
                    goUp2 = goLeft2 = goRight2 = false;
                    goDown2 = true;
                    pacman2.RenderTransform = new RotateTransform(90, pacman2.Width / 2, pacman2.Height / 2);
                }
            }

        }

        private void GameSetUp()
        {
            // this function will run when the program loads

            MyCanvas.Focus(); // set my canvas as the main focus for the program

            gameTimer.Tick += GameLoop; // link the game loop event to the time tick
            gameTimer.Interval = TimeSpan.FromMilliseconds(20); // set time to tick every 20 milliseconds
            // note: the timer is NOT started here - it only starts once the player picks
            // Solo or Co-op on the start menu (see SoloButton_Click / CoopButton_Click)
            currentGhostStep = ghostMoveStep; // set current ghost step to the ghost move step

            // remember where everyone starts so we can reset the board later without restarting the app
            pacmanStartLeft = Canvas.GetLeft(pacman);
            pacmanStartTop = Canvas.GetTop(pacman);
            pacman2StartLeft = Canvas.GetLeft(pacman2);
            pacman2StartTop = Canvas.GetTop(pacman2);
            redGuyStartLeft = Canvas.GetLeft(redGuy);
            redGuyStartTop = Canvas.GetTop(redGuy);
            orangeGuyStartLeft = Canvas.GetLeft(orangeGuy);
            orangeGuyStartTop = Canvas.GetTop(orangeGuy);
            pinkGuyStartLeft = Canvas.GetLeft(pinkGuy);
            pinkGuyStartTop = Canvas.GetTop(pinkGuy);
            blueGuyStartLeft = Canvas.GetLeft(blueGuy);
            blueGuyStartTop = Canvas.GetTop(blueGuy);

            // count how many coins exist on the map so the win condition doesn't rely on a hardcoded number
            totalCoins = MyCanvas.Children.OfType<Rectangle>().Count(r => (string)r.Tag == "coin");

            // below pac man and the ghosts images are being imported from the images folder and then we are assigning the image brush to the rectangles
            ImageBrush pacmanImage = new ImageBrush();
            pacmanImage.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/pacman.jpg"));
            pacman.Fill = pacmanImage;

            ImageBrush pacman2Image = new ImageBrush();
            pacman2Image.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/pacman.jpg"));
            pacman2.Fill = pacman2Image;

            ImageBrush redGhost = new ImageBrush();
            redGhost.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/red.jpg"));
            redGuy.Fill = redGhost;

            ImageBrush orangeGhost = new ImageBrush();
            orangeGhost.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/orange.jpg"));
            orangeGuy.Fill = orangeGhost;

            ImageBrush pinkGhost = new ImageBrush();
            pinkGhost.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/pink.jpg"));
            pinkGuy.Fill = pinkGhost;

            ImageBrush blueGhost = new ImageBrush();
            blueGhost.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/blue.jpg"));
            blueGuy.Fill = blueGhost;

            // fruit image - shared brush is fine since both rectangles just read from it
            ImageBrush fruitImage = new ImageBrush();
            fruitImage.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/fruit.jpg"));
            fruit1.Fill = fruitImage;
            fruit2.Fill = fruitImage;

            // load the sound effects (does nothing if the files aren't in the sounds folder yet)
            LoadSound(fruitSound, "fruit.wav");
            LoadSound(deathSound, "death.wav");
            LoadSound(winSound, "win.wav");

            // set up the lives display
            lives = startingLives;
            txtLives.Content = "Vidas: " + lives;

        }

        private void EasyButton_Click(object sender, RoutedEventArgs e)
        {
            SetDifficulty(Difficulty.Easy);
            ShowPlayerCountMenu();
        }

        private void MediumButton_Click(object sender, RoutedEventArgs e)
        {
            SetDifficulty(Difficulty.Medium);
            ShowPlayerCountMenu();
        }

        private void HardButton_Click(object sender, RoutedEventArgs e)
        {
            SetDifficulty(Difficulty.Hard);
            ShowPlayerCountMenu();
        }

        private void SetDifficulty(Difficulty chosen)
        {
            difficulty = chosen;

            switch (chosen)
            {
                case Difficulty.Easy:
                    // only the 3 original ghosts, moving a bit slower than normal
                    initialGhostSpeed = 7;
                    startingLives = 3;
                    break;

                case Difficulty.Medium:
                    // only the 3 original ghosts, normal speed
                    initialGhostSpeed = 10;
                    startingLives = 3;
                    break;

                case Difficulty.Hard:
                    // all 4 ghosts, normal speed, but only 2 lives instead of 3
                    initialGhostSpeed = 10;
                    startingLives = 2;
                    break;
            }
        }

        private void ShowPlayerCountMenu()
        {
            DifficultyMenuOverlay.Visibility = Visibility.Collapsed;
            PlayerCountMenuOverlay.Visibility = Visibility.Visible;
        }

        private void SoloButton_Click(object sender, RoutedEventArgs e)
        {
            // 1-player mode: player 2 stays hidden and out of the game entirely
            twoPlayerMode = false;
            pacman2.Visibility = Visibility.Collapsed;
            StartGame();
        }

        private void CoopButton_Click(object sender, RoutedEventArgs e)
        {
            // 2-player co-op: player 2 appears and becomes controllable with WASD
            twoPlayerMode = true;
            pacman2.Visibility = Visibility.Visible;
            StartGame();
        }

        private void StartGame()
        {
            // hides the player-count menu and kicks off the game loop, once solo/co-op has been chosen.
            // this also applies whatever difficulty was picked: lives, ghost speed, and whether
            // the 4th ghost takes part - all handled inside ResetBoardState -> ResetPositions
            PlayerCountMenuOverlay.Visibility = Visibility.Collapsed;
            ResetBoardState();
            MyCanvas.Focus();
            gameTimer.Start();
        }

        private void LoadSound(MediaPlayer player, string fileName)
        {
            // points a MediaPlayer at a .wav file inside the "sounds" folder next to the exe.
            // if the file doesn't exist yet, we just leave the player empty - PlaySound below
            // already checks for that, so the game keeps working fine either way.
            try
            {
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sounds", fileName);
                if (System.IO.File.Exists(path))
                {
                    player.Open(new Uri(path));
                }
            }
            catch
            {
                // ignore any load errors (e.g. corrupt file) so the game keeps running
            }
        }

        private void PlaySound(MediaPlayer player)
        {
            try
            {
                if (player.Source != null)
                {
                    player.Stop(); // rewind to the start in case it's already playing
                    player.Play();
                }
            }
            catch
            {
                // ignore any playback errors so the game keeps running
            }
        }

        private void GameLoop(object sender, EventArgs e)
        {

            // this is the game loop event, this event will control all of the movements, outcome, collision and score for the game

            txtScore.Content = "Score: " + score; // show the scoreo to the txtscore label. 

            // start moving the character in the movement directions

            if (goRight)
            {
                // if go right boolean is true then move pac man to the right direction by adding the speed to the left 
                Canvas.SetLeft(pacman, Canvas.GetLeft(pacman) + speed);
            }
            if (goLeft)
            {
                // if go left boolean is then move pac man to the left direction by deducting the speed from the left
                Canvas.SetLeft(pacman, Canvas.GetLeft(pacman) - speed);
            }
            if (goUp)
            {
                // if go up boolean is true then deduct the speed integer from the top position of the pac man
                Canvas.SetTop(pacman, Canvas.GetTop(pacman) - speed);
            }
            if (goDown)
            {
                // if go down boolean is true then add speed integer value to the pac man top position
                Canvas.SetTop(pacman, Canvas.GetTop(pacman) + speed);
            }
            // end the movement 


            // restrict the movement
            if (goDown && Canvas.GetTop(pacman) + 80 > Application.Current.MainWindow.Height)
            {
                // if pac man is moving down the position of pac man is grater than the main window height then stop down movement
                noDown = true;
                goDown = false;
            }
            if (goUp && Canvas.GetTop(pacman) < 1)
            {
                // is pac man is moving and position of pac man is less than 1 then stop up movement
                noUp = true;
                goUp = false;
            }
            if (goLeft && Canvas.GetLeft(pacman) - 10 < 1)
            {
                // if pac man is moving left and pac man position is less than 1 then stop moving left
                noLeft = true;
                goLeft = false;
            }
            if (goRight && Canvas.GetLeft(pacman) + 70 > Application.Current.MainWindow.Width)
            {
                // if pac man is moving right and pac man position is greater than the main window then stop moving right
                noRight = true;
                goRight = false;
            }

            pacmanHitBox = new Rect(Canvas.GetLeft(pacman), Canvas.GetTop(pacman), pacman.Width, pacman.Height); // asssign the pac man hit box to the pac man rectangle

            // player 2's movement (co-op only) - same rules as player 1, just mirrored to its own booleans
            if (twoPlayerMode)
            {
                if (goRight2) Canvas.SetLeft(pacman2, Canvas.GetLeft(pacman2) + speed);
                if (goLeft2) Canvas.SetLeft(pacman2, Canvas.GetLeft(pacman2) - speed);
                if (goUp2) Canvas.SetTop(pacman2, Canvas.GetTop(pacman2) - speed);
                if (goDown2) Canvas.SetTop(pacman2, Canvas.GetTop(pacman2) + speed);

                if (goDown2 && Canvas.GetTop(pacman2) + 80 > Application.Current.MainWindow.Height)
                {
                    noDown2 = true;
                    goDown2 = false;
                }
                if (goUp2 && Canvas.GetTop(pacman2) < 1)
                {
                    noUp2 = true;
                    goUp2 = false;
                }
                if (goLeft2 && Canvas.GetLeft(pacman2) - 10 < 1)
                {
                    noLeft2 = true;
                    goLeft2 = false;
                }
                if (goRight2 && Canvas.GetLeft(pacman2) + 70 > Application.Current.MainWindow.Width)
                {
                    noRight2 = true;
                    goRight2 = false;
                }

                pacman2HitBox = new Rect(Canvas.GetLeft(pacman2), Canvas.GetTop(pacman2), pacman2.Width, pacman2.Height);
            }

            // below is the main game loop that will scan through all of the rectangles available inside of the game
            foreach (var x in MyCanvas.Children.OfType<Rectangle>())
            {
                // loop through all of the rectangles inside of the game and identify them using the x variable


                Rect hitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height); // create a new rect called hit box for all of the available rectangles inside of the game

                // find the walls, if any of the rectangles inside of the game has the tag wall inside of it
                if ((string)x.Tag == "wall")
                {
                    // check if we are colliding with the wall while moving left if true then stop the pac man movement
                    if (goLeft == true && pacmanHitBox.IntersectsWith(hitBox))
                    {
                        Canvas.SetLeft(pacman, Canvas.GetLeft(pacman) + 10);
                        noLeft = true;
                        goLeft = false;
                    }
                    // check if we are colliding with the wall while moving right if true then stop the pac man movement
                    if (goRight == true && pacmanHitBox.IntersectsWith(hitBox))
                    {
                        Canvas.SetLeft(pacman, Canvas.GetLeft(pacman) - 10);
                        noRight = true;
                        goRight = false;
                    }
                    // check if we are colliding with the wall while moving down if true then stop the pac man movement
                    if (goDown == true && pacmanHitBox.IntersectsWith(hitBox))
                    {
                        Canvas.SetTop(pacman, Canvas.GetTop(pacman) - 10);
                        noDown = true;
                        goDown = false;
                    }
                    // check if we are colliding with the wall while moving up if true then stop the pac man movement
                    if (goUp == true && pacmanHitBox.IntersectsWith(hitBox))
                    {
                        Canvas.SetTop(pacman, Canvas.GetTop(pacman) + 10);
                        noUp = true;
                        goUp = false;
                    }

                    // same wall checks, but for player 2 (co-op only)
                    if (twoPlayerMode)
                    {
                        if (goLeft2 == true && pacman2HitBox.IntersectsWith(hitBox))
                        {
                            Canvas.SetLeft(pacman2, Canvas.GetLeft(pacman2) + 10);
                            noLeft2 = true;
                            goLeft2 = false;
                        }
                        if (goRight2 == true && pacman2HitBox.IntersectsWith(hitBox))
                        {
                            Canvas.SetLeft(pacman2, Canvas.GetLeft(pacman2) - 10);
                            noRight2 = true;
                            goRight2 = false;
                        }
                        if (goDown2 == true && pacman2HitBox.IntersectsWith(hitBox))
                        {
                            Canvas.SetTop(pacman2, Canvas.GetTop(pacman2) - 10);
                            noDown2 = true;
                            goDown2 = false;
                        }
                        if (goUp2 == true && pacman2HitBox.IntersectsWith(hitBox))
                        {
                            Canvas.SetTop(pacman2, Canvas.GetTop(pacman2) + 10);
                            noUp2 = true;
                            goUp2 = false;
                        }
                    }

                }

                // check if the any of the rectangles has a coin tag inside of them
                if ((string)x.Tag == "coin")
                {
                    // if either player collides with the coin and it's still visible
                    bool touchedByEither = pacmanHitBox.IntersectsWith(hitBox) || (twoPlayerMode && pacman2HitBox.IntersectsWith(hitBox));
                    if (touchedByEither && x.Visibility == Visibility.Visible)
                    {
                        // set the coin visiblity to hidden
                        x.Visibility = Visibility.Hidden;
                        // add 1 to the score
                        score++;
                        // also track it separately so the win condition works no matter how many fruit points are added
                        coinsCollected++;
                    }

                }

                // check if any of the rectangles has a fruit tag inside of them
                if ((string)x.Tag == "fruit")
                {
                    // if either player collides with a fruit that is still visible
                    bool touchedByEither = pacmanHitBox.IntersectsWith(hitBox) || (twoPlayerMode && pacman2HitBox.IntersectsWith(hitBox));
                    if (touchedByEither && x.Visibility == Visibility.Visible)
                    {
                        // hide the fruit and award its points
                        x.Visibility = Visibility.Hidden;
                        score += 10;
                        PlaySound(fruitSound);

                        // grant the ability to eat the next ghost pacman touches.
                        // this does NOT stack: if the power is already active, eating another
                        // fruit still only allows killing a single ghost before it wears off
                        canEatGhost = true;
                    }
                }


                // if any rectangle has the tag ghost inside of it
                if ((string)x.Tag == "ghost" && x.Visibility == Visibility.Visible)
                {
                    // check if either player collides with the ghost
                    bool touchedByEither = pacmanHitBox.IntersectsWith(hitBox) || (twoPlayerMode && pacman2HitBox.IntersectsWith(hitBox));
                    if (touchedByEither)
                    {
                        if (canEatGhost)
                        {
                            // pacman has fruit power: this ghost gets eaten instead of killing pacman.
                            // it's removed from the game for good (does not respawn) and the power-up is consumed (no stacking)
                            EatGhost(x);
                            canEatGhost = false;
                        }
                        else
                        {
                            // no power active, so the ghost gets pacman instead -
                            // this costs a life; the game only ends if that was the last one
                            LoseLife();
                        }
                    }

                    // if there is a rectangle called orange guy in the game
                    if (x.Name.ToString() == "orangeGuy")
                    {
                        // move that rectangle to towards the left of the screen
                        Canvas.SetLeft(x, Canvas.GetLeft(x) - ghostSpeed);

                    }
                    else
                    {
                        // other ones can move towards the right of the screen
                        Canvas.SetLeft(x, Canvas.GetLeft(x) + ghostSpeed);
                    }

                    }
                }

            // keep the ghosts' periodic direction flip independent of how many ghosts are
            // still alive on the board - previously this counted down once per visible ghost
            // inside the loop above, so eating a ghost changed the rate and made the
            // remaining ghosts overshoot their turn-around point and wander off screen
            currentGhostStep -= 3; // same overall rate as before, when all 3 ghosts counted it down together
            if (currentGhostStep < 1)
            {
                currentGhostStep = ghostMoveStep;
                ghostSpeed = -ghostSpeed;
            }


            // if the player collected every coin on the map

            if (coinsCollected == totalCoins)
            {
                // show game over function with the you win message
                PlaySound(winSound);
                GameOver("Você Venceu!", "Parabéns, você coletou todas as moedas!");
            }

            // update the power-up glow that surrounds pacman while he can eat a ghost
            if (canEatGhost)
            {
                pacmanPowerGlow.Visibility = Visibility.Visible;

                // keep the glow centered on pacman as he moves
                Canvas.SetLeft(pacmanPowerGlow, Canvas.GetLeft(pacman) - 5);
                Canvas.SetTop(pacmanPowerGlow, Canvas.GetTop(pacman) - 5);

                // flip its opacity every few ticks so it flashes instead of staying solid
                glowFlashCounter++;
                double glowOpacity = (glowFlashCounter / 8 % 2 == 0) ? 1.0 : 0.2;
                pacmanPowerGlow.Opacity = glowOpacity;

                // the power is shared by the team, so show it around player 2 as well (co-op only)
                if (twoPlayerMode)
                {
                    pacman2PowerGlow.Visibility = Visibility.Visible;
                    Canvas.SetLeft(pacman2PowerGlow, Canvas.GetLeft(pacman2) - 5);
                    Canvas.SetTop(pacman2PowerGlow, Canvas.GetTop(pacman2) - 5);
                    pacman2PowerGlow.Opacity = glowOpacity;
                }
            }
            else
            {
                pacmanPowerGlow.Visibility = Visibility.Collapsed;
                pacman2PowerGlow.Visibility = Visibility.Collapsed;
                glowFlashCounter = 0;
            }

        }

        private void LoseLife()
        {
            // a ghost caught pacman with no power active: this costs one life
            PlaySound(deathSound);
            lives--;
            txtLives.Content = "Vidas: " + lives;

            if (lives <= 0)
            {
                // no lives left - the game is truly over
                GameOver("Você Perdeu!", "Você ficou sem vidas. Tente novamente!");
            }
            else
            {
                // still has lives left - respawn everyone and keep playing.
                // score, coins and fruit already collected are NOT lost.
                ResetPositions();
            }
        }

        private void ResetPositions()
        {
            // puts pacman and all 3 ghosts back at their starting spots, with a clean
            // movement/power-up state. Used both after losing a life and on a full restart.

            goLeft = goRight = goUp = goDown = false;
            noLeft = noRight = noUp = noDown = false;

            // pacman, facing right
            Canvas.SetLeft(pacman, pacmanStartLeft);
            Canvas.SetTop(pacman, pacmanStartTop);
            pacman.RenderTransform = new RotateTransform(0, pacman.Width / 2, pacman.Height / 2);

            // player 2, facing left (mirrored start), co-op only
            if (twoPlayerMode)
            {
                goLeft2 = goRight2 = goUp2 = goDown2 = false;
                noLeft2 = noRight2 = noUp2 = noDown2 = false;
                Canvas.SetLeft(pacman2, pacman2StartLeft);
                Canvas.SetTop(pacman2, pacman2StartTop);
                pacman2.RenderTransform = new RotateTransform(0, pacman2.Width / 2, pacman2.Height / 2);
            }

            // every ghost, visible again even if one had been eaten
            Canvas.SetLeft(redGuy, redGuyStartLeft);
            Canvas.SetTop(redGuy, redGuyStartTop);
            redGuy.Visibility = Visibility.Visible;
            Canvas.SetLeft(orangeGuy, orangeGuyStartLeft);
            Canvas.SetTop(orangeGuy, orangeGuyStartTop);
            orangeGuy.Visibility = Visibility.Visible;
            Canvas.SetLeft(pinkGuy, pinkGuyStartLeft);
            Canvas.SetTop(pinkGuy, pinkGuyStartTop);
            pinkGuy.Visibility = Visibility.Visible;
            Canvas.SetLeft(blueGuy, blueGuyStartLeft);
            Canvas.SetTop(blueGuy, blueGuyStartTop);
            // the 4th ghost only takes part on Hard - Visibility.Collapsed keeps it
            // out of movement/collision entirely (both are gated on Visibility.Visible)
            blueGuy.Visibility = (difficulty == Difficulty.Hard) ? Visibility.Visible : Visibility.Collapsed;

            ghostSpeed = initialGhostSpeed;
            currentGhostStep = ghostMoveStep;

            // clear the power-up state
            canEatGhost = false;
            glowFlashCounter = 0;
            pacmanPowerGlow.Visibility = Visibility.Collapsed;
            pacman2PowerGlow.Visibility = Visibility.Collapsed;

            MyCanvas.Focus();
        }

        private void EatGhost(Rectangle ghost)
        {
            // pacman ate this ghost: remove it from the game for good.
            // it will only come back after losing a life or restarting the game
            ghost.Visibility = Visibility.Hidden;
        }

        private void GameOver(string title, string message)
        {
            // inside the game over function we stop the game and show a nice overlay
            // with the result instead of a plain system MessageBox
            gameTimer.Stop(); // stop the game timer

            txtGameOverTitle.Text = title; // "Você Venceu!" or "Você Perdeu!"
            txtGameOverMessage.Text = message; // the friendly explanation text
            txtFinalScore.Text = "Score final: " + score; // show how many coins were collected

            GameOverOverlay.Visibility = Visibility.Visible; // reveal the overlay panel
        }

        private void RestartButton_Click(object sender, RoutedEventArgs e)
        {
            // the player clicked "Jogar Novamente": reset everything and jump straight back
            // into the same mode (Solo/Co-op) that was already chosen
            ResetBoardState();
            GameOverOverlay.Visibility = Visibility.Collapsed;
            gameTimer.Start();
        }

        private void BackToMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // the player clicked "Voltar ao Menu Inicial": reset everything and go all the way
            // back to the very first screen (difficulty), so both difficulty and mode can be re-chosen
            ResetBoardState();
            GameOverOverlay.Visibility = Visibility.Collapsed;
            DifficultyMenuOverlay.Visibility = Visibility.Visible;
            // note: gameTimer stays stopped here - it only starts again once
            // SoloButton_Click or CoopButton_Click runs (see StartGame)
        }

        private void ResetBoardState()
        {
            // shared reset logic used both for a quick restart and for going back to the menu:
            // clears score/lives and puts every position/coin/fruit back to how the game started

            score = 0;
            coinsCollected = 0;
            lives = startingLives;
            txtLives.Content = "Vidas: " + lives;

            ResetPositions();

            // make every coin and fruit visible again
            foreach (var x in MyCanvas.Children.OfType<Rectangle>())
            {
                if ((string)x.Tag == "coin" || (string)x.Tag == "fruit")
                {
                    x.Visibility = Visibility.Visible;
                }
            }
        }



    }
}